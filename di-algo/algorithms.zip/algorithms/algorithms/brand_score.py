from base import Base


class BrandScore(Base):

    # fetched from database in init
    BRAND_EQUITY_RANGES = {"branded_search_volume" : [0.4, (2,4,6,8,10)],
                           "branded_anchor_text_count" : [0.1, (25, 50, 100, 250, 500, 1000, 2500)],
                           "facebook_presence" : [0.03, (10, 20, 30, 70, 90)],
                           "facebook_strength" : [0.1, (2,4,6,8,10)],
                           "twitter_presence" : [0.03, (10, 20, 30, 70, 90)],
                           "twitter_strength" : [0.1, (2,4,6,8,10)],
                           "linkedin_presence" : [0.01, (10, 20, 30, 70, 90)],
                           "brand_mentions" : [0.05, (10, 20, 30, 70, 90)]
                          }

    BRAND_TRUST_RANGES = {"total_review_count" : [0.2, (25, 50, 100, 250, 500, 1000, 2500)],
                          "total_unique_sources" : [0.3, (2,4,6,8,10)],
                          "average_review_score" : [0.5, (10, 20, 30, 70, 90)]
                         }

    def get_results(self, statement):
        
        equity_total = self.get_single_score(self.BRAND_EQUITY_RANGES, statement)
        trust_total = self.get_single_score(self.BRAND_TRUST_RANGES, statement)

        total = equity_total + (trust_total * 0.2)
        return total
