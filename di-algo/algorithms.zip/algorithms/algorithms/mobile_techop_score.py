from base import Base


class MobileTechOpScore(Base):

    # fetched from database in init
    MOBILE_TECHOP_RANGES = {"page_speed" : [0.35, ()],
                            "average_first_paint_load_speed" : [0.05, ()],
                            "first_contentful_paint_load_speed" : [0.05, ()],
                            "average_frontend_time_speed" : [0.03, ()],
                            "backend_load_time_speed" : [0.03, ()],
                            "google_page_speed_insights_score" : [0.07, ()],
                            "dom_content_loaded_time" : [0.005, ()],
                            "dom_interactive_time" : [0.005, ()],
                            "server_connections_time" : [0.005, ()],
                            "server_response_time" : [0.005, ()],
                            "page_size" : [0.03, ()],
                            "image_size" : [0.02, ()],
                            "javascript_size" : [0.02, ()],
                            "css_size" : [0.01, ()],
                            "html_requests" : [0.01, ()],
                            "css_requests" : [0.01, ()],
                            "javascript_requests" : [0.01, ()],
                            "image_requests" : [0.001, ()],
                            "document_height" : [0.003, ()],
                            "dom_elements" : [0.001, ()],
                            "page_response_code" : [0.05, ()],
                            "sll_https_malware_security" : [0.05, ()],
                            "page_mobile_friendly_design" : [0.06, ()],
                            "document_structure_score" : [0.035, ()],
                            "document_best_practice_score" : [0.03, ()],
                            "first_visual_change" : [0.03, ()],
                            "last_visual_change" : [0.03, ()]
                           }

    def get_results(self, statement):

        total = self.get_single_score(self.MOBILE_TECHOP_RANGES, statement)

        return total
