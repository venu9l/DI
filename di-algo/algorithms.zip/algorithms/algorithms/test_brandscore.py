from base import Base

SITEMAPE_RANGES = {"sitemap_presence" : [0.03, [1]],
                   "breadcrumb_navigation_structure" : [0.02, (0, 25, 50, 75)],
                   "average_page_crawl_depth" : [0.25, (3, 5, 7)],
                   "folder_to_page_standard_deviation" : [0.01, (75, 50, 25, 10, 5)],
                   "internal_backlink_to_folder_standard_deviation" : [.02, (75, 50, 25, 10, 5)],
                   "percentage_of_pages_internally_linked" : [0.15, (10, 20, 30, 50, 75)],
                   "total_pages_indexed_national" : [0.15, (10000, 25000, 50000, 100000, 150000)],
                   "total_pages_indexed_local" : [0.15, (100, 500, 1000, 20000, 5000)],
                   "total_pages_indexed_major" : [0.15, (500, 2000, 5000, 7500, 10000)],
                   "total_pages_indexed_minor" : [0.15, (50000, 100000, 500000, 2000000, 5000000)]
                      }

MOBILE_TECHOP_RANGES = {"page_speed" : [0.35, ()],
                        "average_first_paint_load_speed" : [0.05, ()],
                        "first_contentful_paint_load_speed" : [0.05, ()],
                        "average_frontend_time_speed" : [0.03, ()],
                        "backend_load_time_speed" : [0.03, ()],
                        "google_page_speed_insights_score" : [0.07, ()],
                        "dom_content_loaded_time" : [0.005, ()],
                        "dom_interactive_time" : [0.005, ()],
                        "server_connections_time" : [0.005, ()],
                        "server_response_time" : [0.005, ()],
                        "page_size" : [0.03, ()],
                        "image_size" : [0.02, ()],
                        "javascript_size" : [0.02, ()],
                        "css_size" : [0.01, ()],
                        "html_requests" : [0.01, ()],
                        "css_requests" : [0.01, ()],
                        "javascript_requests" : [0.01, ()],
                        "image_requests" : [0.001, ()],
                        "document_height" : [0.003, ()],
                        "dom_elements" : [0.001, ()],
                        "page_response_code" : [0.05, ()],
                        "sll_https_malware_security" : [0.05, ()],
                        "page_mobile_friendly_design" : [0.06, ()],
                        "document_structure_score" : [0.035, ()],
                        "document_best_practice_score" : [0.03, ()],
                        "first_visual_change" : [0.03, ()],
                        "last_visual_change" : [0.03, ()]
                       }

# print(BrandScore.brand_score(BrandScore, 34,34342,25656))
test = Base()

name = "sitemap"
company = "valuepenguin"
statement = "select * from " + name + " where " + name + "name = '" + company + "'"

finish = test.get_single_score(SITEMAPE_RANGES, statement)

# finish = test.create_table('sitemap', SITEMAPE_RANGES)
# finish = test.create_dummy('sitemap', 'valuepenguin', SITEMAPE_RANGES)

print(finish)