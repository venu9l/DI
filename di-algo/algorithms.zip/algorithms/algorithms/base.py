from database import DBConnection

class Base(DBConnection):

    def points(self, source_range, value):
        score = 0
        if value:
            for x in source_range:
                score += 1
                if value <= x:
                    return score
            return score + 1
        else:
            return score

    def get_single_score(self, database, statement):
        results = self.read(statement)

        totals = float(0)
        # [0] is the weight%, [1] is the range
        for item in database:
            # import pdb ; pdb.set_trace()
            score = self.points(database[item][1], results[0][item]) * database[item][0]
            totals += score

        return totals

    def create_table(self, name, database):
        string = "CREATE TABLE " + name + " (" + name + "name varchar(20), "
        for x in database:
            string += x + " int, "
        string = string[0:-2] + ");"
        return string

    def create_dummy(self, table, name, database):
        import random
        string = "INSERT INTO " + table + " VALUES ('" + name + "', "
        for x in database:
            var = random.randint(1,100001)
            string += str(var) + ", "
        string = string[0:-2] + ");"
        return string