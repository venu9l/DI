from base import Base


class DomainScore(Base):

    # fetched from database in init
    DOMAIN_RANGES = {"backlink_score" : [0.05, ()],
                     "seo_content_quality_score" : [0.05, ()],
                     "auxiliary_content_quality_score" : [0.05, ()],
                     "brand_equity_score" : [0.05, ()],
                     "site_architecture_score" : [0.05, ()],
                     "mobile_optimization_score" : [0.05, ()],
                     "technical_optimization_performance_score" : [0.05, ()],
                     "total_keywords_ranking_fg" : [0.05, ()],
                     "page_publication_rate" : [0.05, ()],
                     "keyword_search_volume_target_sr" : [0.05, ()],
                     "percentage_of_pages_ranking_from_total" : [0.05, ()],
                     "domain_age" : [0.05, ()],
                     "keyword_in_top_level_domain" : [0.05, ()],
                     "domain_registration_length" : [0.05, ()],
                     "total_number_of_pages_sr" : [0.05, ()],
                     "keywords_top_positions_sr" : [0.05, ()],
                     "page_average_position" : [0.05, ()],
                     "primary_keyword_average_position" : [0.05, ()],
                     "search_volume_market_share_sr" : [0.05, ()],
                     "total_seo_pages_sr" : [0.05, ()]
                    }

    DETRACTORS = {"common_popups_distracting_ads" : [-0.02, ()],
                  "unnatural_link_influx_td" : [-0.02, ()],
                  "internal_duplicate_content_value" : [-0.02, ()],
                  "average_page_outbound_links" : [-0.02, ()],
                  "outgoing_link_spam_score" : [-0.02, ()]
                 }

    def get_results(self, statement):
        
        domain_total = self.get_single_score(self.DOMAIN_RANGES, statement)
        detraction = self.get_single_score(self.BRAND_TRUST_RANGES, statement)

        total = domain_total + detraction
        return total
