from base import Base


class SitemapScore(Base):

    # fetched from database in init
    SITEMAPE_RANGES = {"sitemap_presence" : [0.03, (1)],
                       "breadcrumb_navigation_structure" : [0.02, (0, 25, 50, 75)],
                       "average_page_crawl_depth" : [0.25, (3, 5, 7)],
                       "folder_to_page_standard_deviation" : [0.01, (75, 50, 25, 10, 5)],
                       "internal_backlink_to_folder_standard_deviation" : [.02, (75, 50, 25, 10, 5)],
                       "percentage_of_pages_internally_linked" : [0.15, (10, 20, 30, 50, 75)],
                       "total_pages_indexed_national" : [0.15, (10000, 25000, 50000, 100000, 150000)],
                       "total_pages_indexed_local" : [0.15, (100, 500, 1000, 20000, 5000)],
                       "total_pages_indexed_major" : [0.15, (500, 2000, 5000, 7500, 10000)],
                       "total_pages_indexed_minor" : [0.15, (50000, 100000, 500000, 2000000, 5000000)]
                      }

    def get_results(self, statement):
        
        total = self.get_single_score(self.SITEMAPE_RANGES, statement)
        
        return total
